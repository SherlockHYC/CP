#include "vector.h"

vector initVector() {}
void pushbackVector(vector* vec, int32_t val) {}
void popbackVector(vector* vec) {}
void clearVector(vector* vec) {}
void eraseVector(vector* vec, int index) {}